-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: livrariasucesso
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autores_livros`
--

DROP TABLE IF EXISTS `autores_livros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autores_livros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_autor` int(11) DEFAULT NULL,
  `id_livro` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chave_livros` (`id_livro`),
  KEY `chave_autores` (`id_autor`),
  CONSTRAINT `chave_autores` FOREIGN KEY (`id_autor`) REFERENCES `autores` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `chave_livros` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autores_livros`
--

LOCK TABLES `autores_livros` WRITE;
/*!40000 ALTER TABLE `autores_livros` DISABLE KEYS */;
INSERT INTO `autores_livros` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,1,11),(12,2,12),(13,3,13),(14,4,14),(15,5,15),(16,6,16),(17,7,17),(18,8,18),(19,9,19),(20,10,20),(21,1,21),(22,2,22),(23,3,23),(24,4,24),(25,5,25),(26,6,26),(27,7,27),(28,8,28),(29,9,29),(30,10,30),(31,1,31),(32,2,32),(33,3,33),(34,4,34),(35,5,35),(36,6,36),(37,7,37),(38,8,38),(39,9,39),(40,10,40),(41,1,41),(42,2,42),(43,3,43),(44,4,44),(45,5,45),(46,6,46),(47,7,47),(48,8,48),(49,9,49),(50,10,50),(51,1,51),(52,2,52),(53,3,53),(54,4,54),(55,5,55),(56,6,56),(57,7,57),(58,8,58),(59,9,59),(60,10,60),(61,1,61),(62,2,62),(63,3,63),(64,4,64),(65,5,65),(66,6,66),(67,7,67),(68,8,68),(69,9,69),(70,10,70),(71,1,71),(72,2,72),(73,3,73),(74,4,74),(75,5,75),(76,6,76),(77,7,77),(78,8,78),(79,9,79),(80,10,80),(81,1,81),(82,2,82),(83,3,83),(84,4,84),(85,5,85),(86,6,86),(87,7,87),(88,8,88),(89,9,89),(90,10,90),(91,1,91),(92,2,92),(93,3,93),(94,4,94),(95,5,95),(96,6,96),(97,7,97),(98,8,98),(99,9,99),(100,10,100),(101,1,101),(102,2,50),(103,3,20),(104,4,33),(105,5,40),(106,6,55),(107,7,77),(108,8,88),(109,9,99),(110,10,101),(111,1,10),(112,2,30),(113,3,60),(114,4,90),(115,5,25),(116,6,35),(117,7,65),(118,8,85),(119,9,45),(120,10,75);
/*!40000 ALTER TABLE `autores_livros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 18:11:41
