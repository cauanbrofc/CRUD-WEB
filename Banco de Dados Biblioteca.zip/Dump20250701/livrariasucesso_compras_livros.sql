-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: livrariasucesso
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `compras_livros`
--

DROP TABLE IF EXISTS `compras_livros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras_livros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_compra` int(11) DEFAULT NULL,
  `id_livro` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `valor_compra` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chave_compra` (`id_compra`),
  KEY `chave_livro` (`id_livro`),
  CONSTRAINT `chave_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `chave_livro` FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras_livros`
--

LOCK TABLES `compras_livros` WRITE;
/*!40000 ALTER TABLE `compras_livros` DISABLE KEYS */;
INSERT INTO `compras_livros` VALUES (1,1,10,2,45.9),(2,2,25,1,30.5),(3,3,40,3,20.75),(4,3,60,1,15.99),(5,5,12,2,55.8),(6,6,85,1,65.4),(7,7,32,3,22),(8,8,50,2,40.99),(9,9,77,1,48),(10,10,101,2,35.6),(11,11,15,1,25.5),(12,12,63,2,18.3),(13,13,28,3,45.2),(14,13,91,1,60.9),(15,15,5,2,20.75),(16,16,45,1,33.4),(17,17,80,3,50),(18,18,22,2,38.99),(19,19,99,1,55),(20,20,9,2,42.6),(21,21,35,3,47.5),(22,22,78,1,29.3),(23,23,11,2,21.2),(24,23,66,1,32.9),(25,25,89,2,44.75),(26,26,30,3,27.4),(27,27,55,1,39.9),(28,28,98,2,53.8),(29,29,42,1,60),(30,29,71,3,19.99);
/*!40000 ALTER TABLE `compras_livros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 18:11:40
