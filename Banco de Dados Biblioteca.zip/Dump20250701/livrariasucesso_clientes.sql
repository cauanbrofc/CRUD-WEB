-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: livrariasucesso
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'João Silva','1990-05-14','11999990001','joao@email.com','Rua A, 100'),(2,'Maria Souza','1985-08-22','11999990002','maria@email.com','Rua B, 200'),(3,'Carlos Lima','1992-11-03','11999990003','carlos@email.com','Rua C, 300'),(4,'Ana Pereira','1988-07-19','11999990004','ana@email.com','Rua D, 400'),(5,'Pedro Gomes','1995-02-25','11999990005','pedro@email.com','Rua E, 500'),(6,'Juliana Costa','1991-09-14','11999990006','juliana@email.com','Rua F, 600'),(7,'Lucas Fernandes','1983-05-30','11999990007','lucas@email.com','Rua G, 700'),(8,'Fernanda Alves','1997-12-10','11999990008','fernanda@email.com','Rua H, 800'),(9,'Ricardo Martins','1989-06-27','11999990009','ricardo@email.com','Rua I, 900'),(10,'Mariana Rocha','2000-02-02','11999990010','mariana@email.com','Rua J, 1000'),(11,'Thiago Nunes','1993-08-11','11999990011','thiago@email.com','Rua K, 1100'),(12,'Patrícia Oliveira','1987-04-15','11999990012','patricia@email.com','Rua L, 1200'),(13,'Roberto Santos','1994-03-20','11999990013','roberto@email.com','Rua M, 1300'),(14,'Camila Lima','1986-09-25','11999990014','camila@email.com','Rua N, 1400'),(15,'Gustavo Henrique','1998-07-30','11999990015','gustavo@email.com','Rua O, 1500'),(16,'Isabela Costa','1990-12-05','11999990016','isabela@email.com','Rua P, 1600'),(17,'Felipe Souza','1984-11-10','11999990017','felipe@email.com','Rua Q, 1700'),(18,'Larissa Mendes','1996-06-15','11999990018','larissa@email.com','Rua R, 1800'),(19,'Bruno Almeida','1982-01-20','11999990019','bruno@email.com','Rua S, 1900'),(20,'Carla Ribeiro','1999-08-25','11999990020','carla@email.com','Rua T, 2000'),(21,'Daniel Pereira','1981-05-30','11999990021','daniel@email.com','Rua U, 2100'),(22,'Eduarda Silva','1997-02-10','11999990022','eduarda@email.com','Rua V, 2200'),(23,'Fabio Costa','1983-09-15','11999990023','fabio@email.com','Rua W, 2300'),(24,'Gabriela Souza','1991-04-20','11999990024','gabriela@email.com','Rua X, 2400'),(25,'Henrique Lima','1989-03-25','11999990025','henrique@email.com','Rua Y, 2500'),(26,'Igor Santos','1995-10-30','11999990026','igor@email.com','Rua Z, 2600'),(27,'Juliana Oliveira','1987-07-05','11999990027','juliana@email.com','Rua AA, 2700'),(28,'Karine Alves','1993-12-10','11999990028','karine@email.com','Rua BB, 2800'),(29,'Leonardo Mendes','1985-11-15','11999990029','leonardo@email.com','Rua CC, 2900'),(30,'Mariana Rocha','2000-02-02','11999990030','mariana@email.com','Rua DD, 3000'),(31,'João Cara de bolacha','2005-10-03','92995058519','cleydsonromeu2015@gmail.com','Rua Jardim Mauá'),(32,'Elias O Gaiato','1999-02-10','9293596111','eliasjose@bol.com','mauazinho'),(33,'cleydson romeu oliveira','2005-05-31','92995058519','cleydsonromeu2015@gmail.com','Rua Jardim Mauá');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 18:11:40
