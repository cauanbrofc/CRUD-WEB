-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: livrariasucesso
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `livros`
--

DROP TABLE IF EXISTS `livros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_editora` int(11) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `classe_indicativa` enum('L','+10','+12','+14','+16','+18') DEFAULT NULL,
  `tipo_capa` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chave_editora` (`id_editora`),
  CONSTRAINT `chave_editora` FOREIGN KEY (`id_editora`) REFERENCES `editoras` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livros`
--

LOCK TABLES `livros` WRITE;
/*!40000 ALTER TABLE `livros` DISABLE KEYS */;
INSERT INTO `livros` VALUES (1,1,'Dom Casmurro','1899-01-01','+12','Dura'),(2,2,'A Hora da Estrela','1977-04-01','+14','Mole'),(3,3,'Vidas Secas','1938-06-15','+10','Dura'),(4,4,'O Sítio do Pica-Pau Amarelo','1920-09-10','L','Mole'),(5,5,'Gabriela, Cravo e Canela','1958-02-20','+16','Dura'),(6,6,'Memórias Póstumas de Brás Cubas','1881-06-20','+14','Dura'),(7,1,'Quincas Borba','1891-01-01','+12','Dura'),(8,2,'A Paixão Segundo G.H.','1964-04-01','+14','Mole'),(9,3,'São Bernardo','1934-06-15','+10','Dura'),(10,4,'Reinações de Narizinho','1931-09-10','L','Mole'),(11,5,'Dona Flor e Seus Dois Maridos','1966-02-20','+16','Dura'),(12,6,'O Alienista','1882-06-20','+14','Dura'),(13,1,'Esaú e Jacó','1904-01-01','+12','Dura'),(14,2,'A Via Crucis do Corpo','1974-04-01','+14','Mole'),(15,3,'Angústia','1936-06-15','+10','Dura'),(16,4,'O Minotauro','1939-09-10','L','Mole'),(17,5,'Tenda dos Milagres','1969-02-20','+16','Dura'),(18,6,'A Cartomante','1884-06-20','+14','Dura'),(19,1,'Memorial de Aires','1908-01-01','+12','Dura'),(20,2,'A Legião Estrangeira','1964-04-01','+14','Mole'),(21,3,'Infância','1945-06-15','+10','Dura'),(22,4,'O Picapau Amarelo','1939-09-10','L','Mole'),(23,5,'Teresa Batista Cansada de Guerra','1972-02-20','+16','Dura'),(24,6,'O Espelho','1882-06-20','+14','Dura'),(25,1,'A Mão e a Luva','1874-01-01','+12','Dura'),(26,2,'A Cidade Sitiada','1949-04-01','+14','Mole'),(27,3,'Insônia','1947-06-15','+10','Dura'),(28,4,'O Poço do Visconde','1937-09-10','L','Mole'),(29,5,'Capitães da Areia','1937-02-20','+16','Dura'),(30,6,'A Missão do Artista','1882-06-20','+14','Dura'),(31,1,'Helena','1876-01-01','+12','Dura'),(32,2,'A Maçã no Escuro','1961-04-01','+14','Mole'),(33,3,'Caetés','1933-06-15','+10','Dura'),(34,4,'A Chave do Tamanho','1942-09-10','L','Mole'),(35,5,'Mar Morto','1936-02-20','+16','Dura'),(36,6,'O Homem Célebre','1882-06-20','+14','Dura'),(37,1,'Iaiá Garcia','1878-01-01','+12','Dura'),(38,2,'A Via Crucis do Corpo','1974-04-01','+14','Mole'),(39,3,'Vidas Secas','1938-06-15','+10','Dura'),(40,4,'O Saci','1921-09-10','L','Mole'),(41,5,'Jubiabá','1935-02-20','+16','Dura'),(42,6,'A Cartomante','1884-06-20','+14','Dura'),(43,1,'Memórias de um Sargento de Milícias','1854-01-01','+12','Dura'),(44,2,'A Paixão Segundo G.H.','1964-04-01','+14','Mole'),(45,3,'São Bernardo','1934-06-15','+10','Dura'),(46,4,'Reinações de Narizinho','1931-09-10','L','Mole'),(47,5,'Dona Flor e Seus Dois Maridos','1966-02-20','+16','Dura'),(48,6,'O Alienista','1882-06-20','+14','Dura'),(49,1,'Esaú e Jacó','1904-01-01','+12','Dura'),(50,2,'A Via Crucis do Corpo','1974-04-01','+14','Mole'),(51,3,'Angústia','1936-06-15','+10','Dura'),(52,4,'O Minotauro','1939-09-10','L','Mole'),(53,5,'Tenda dos Milagres','1969-02-20','+16','Dura'),(54,6,'A Cartomante','1884-06-20','+14','Dura'),(55,1,'Memorial de Aires','1908-01-01','+12','Dura'),(56,2,'A Legião Estrangeira','1964-04-01','+14','Mole'),(57,3,'Infância','1945-06-15','+10','Dura'),(58,4,'O Picapau Amarelo','1939-09-10','L','Mole'),(59,5,'Teresa Batista Cansada de Guerra','1972-02-20','+16','Dura'),(60,6,'O Espelho','1882-06-20','+14','Dura'),(61,1,'A Mão e a Luva','1874-01-01','+12','Dura'),(62,2,'A Cidade Sitiada','1949-04-01','+14','Mole'),(63,3,'Insônia','1947-06-15','+10','Dura'),(64,4,'O Poço do Visconde','1937-09-10','L','Mole'),(65,5,'Capitães da Areia','1937-02-20','+16','Dura'),(66,6,'A Missão do Artista','1882-06-20','+18','Dura'),(67,1,'Helena','1876-01-01','+12','Dura'),(68,2,'A Maçã no Escuro','1961-04-01','+18','Mole'),(69,3,'Caetés','1933-06-15','+10','Dura'),(70,4,'A Chave do Tamanho','1942-09-10','L','Mole'),(71,5,'Mar Morto','1936-02-20','+16','Dura'),(72,6,'O Homem Célebre','1882-06-20','+14','Dura'),(73,1,'Iaiá Garcia','1878-01-01','+12','Dura'),(74,2,'A Via Crucis do Corpo','1974-04-01','+14','Mole'),(75,3,'Vidas Secas','1938-06-15','+10','Dura'),(76,4,'O Saci','1921-09-10','L','Mole'),(77,5,'Jubiabá','1935-02-20','+16','Dura'),(78,6,'A Cartomante','1884-06-20','+14','Dura'),(79,1,'Memórias de um Sargento de Milícias','1854-01-01','+12','Dura'),(80,2,'A Paixão Segundo G.H.','1964-04-01','+14','Mole'),(81,3,'São Bernardo','1934-06-15','+10','Dura'),(82,4,'Reinações de Narizinho','1931-09-10','L','Mole'),(83,5,'Dona Flor e Seus Dois Maridos','1966-02-20','+16','Dura'),(84,6,'O Alienista','1882-06-20','+14','Dura'),(85,1,'Esaú e Jacó','1904-01-01','+12','Dura'),(86,2,'A Via Crucis do Corpo','1974-04-01','+14','Mole'),(87,3,'Angústia','1936-06-15','+10','Dura'),(88,4,'O Minotauro','1939-09-10','L','Mole'),(89,5,'Tenda dos Milagres','1969-02-20','+16','Dura'),(90,6,'A Cartomante','1884-06-20','+14','Dura'),(91,6,'A Cartomante','1884-06-20','+14','Mole'),(92,1,'Memorial de Aires','1908-01-01','+12','Dura'),(93,1,'Memorial de Aires','1908-01-01','+12','Mole'),(94,1,'Memorial de Aires','1908-01-01','+12','Mole'),(95,2,'A Legião Estrangeira','1964-04-01','+14','Mole'),(96,2,'A Legião Estrangeira','1964-04-01','+14','Mole'),(97,3,'Infância','1945-06-15','+10','Dura'),(98,1,'A Mão e a Luva','1874-01-01','+12','Dura'),(99,4,'O Picapau Amarelo','1939-09-10','L','Mole'),(100,5,'Teresa Batista Cansada de Guerra','1972-02-20','+16','Dura'),(101,6,'O Espelho','1882-06-20','+14','Dura');
/*!40000 ALTER TABLE `livros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 18:11:42
